#include <GL/glu.h>
#include <GL/glut.h>
#include <stdio.h>

GLfloat win = 150.0f,escala = 1;
GLfloat rotacao = 0;
GLfloat movx = 0, movy = 0;
GLfloat r,g,b;

void desenha()
{
    glClear(GL_COLOR_BUFFER_BIT);    //limpa o buffer e projeta o desenho na tela
    glMatrixMode(GL_PROJECTION);  //se aumentar a tela a forma tamb�m aumente
    glLoadIdentity();
    gluOrtho2D(-3,3,-3,4);   // dimensionar a forma

    /* //trabalha com a escala de teclas *****************************************************************/
    glScaled(escala,escala,0);
    glRotated(rotacao,0,0,1);
    glTranslated(movx,movy,0);
    /*-****************************************************************************************************/

    glMatrixMode(GL_MODELVIEW);  //se aumentar a tela a forma tamb�m aumente
    glLoadIdentity();

    /*---Desenha a primeira forma lendo de um arquivo **********************************************************************************/
    float x,y,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,x7,y7,x8,y8,x9,y9;
    FILE*fp;
    fp = fopen("arquivo.txt","r"); //ele le o arquivo da area de trabalho
    fscanf(fp,"%f %f\n",&x,&y);
    fscanf(fp,"%f %f\n",&x2,&y2);
    fscanf(fp,"%f %f\n",&x3,&y3);
    fscanf(fp,"%f %f\n",&x4,&y4);
    fscanf(fp,"%f %f\n",&x5,&y5);
    fscanf(fp,"%f %f\n",&x6,&y6);
    fscanf(fp,"%f %f\n",&x7,&y7);
    fscanf(fp,"%f %f\n",&x8,&y8);
    fscanf(fp,"%f %f\n",&x9,&y9);
    glPointSize(5);  //define o tamanho do ponto
    glBegin(GL_POINTS);   //come�a um la�o de pontos
    glColor3f(1,1,1);
    glVertex2f(x,y);
    glVertex2f(x2,y2);
    glVertex2f(x3,y3);
    glVertex2f(x4,y4);
    glVertex2f(x5,y5);
    glVertex2f(x6,y6);
    glVertex2f(x7,y7);
    glVertex2f(x8,y8);
    glVertex2f(x9,y9);
    glEnd();
    glFlush();   //elementos carregados no buffer

    glBegin(GL_LINES); //desenha texto na primeira parte
    glVertex2f(-2.0,3.75);
    glVertex2f(-2.0,3.25);
    glVertex2f(-2.0,3.75);
    glVertex2f(-2.1,3.6);
    glEnd();
    glFlush();   //elementos carregados no buffer


    glBegin(GL_LINES); //desenha texto na segunda parte
    glVertex2f(0.0,3.75);
    glVertex2f(-0.15,3.75);
    glVertex2f(-0.15,3.45);
    glVertex2f(0.0,3.45);
    glVertex2f(0.0,3.75);
    glVertex2f(0.0,3.45);
    glVertex2f(-0.15,3.45);
    glVertex2f(-0.15,3.3);
    glVertex2f(-0.15,3.3);
    glVertex2f(0.0,3.3);
    glEnd();
    glFlush();   //elementos carregados no buffer

    glBegin(GL_LINES); //desenha texto na terceira parte
    glVertex2f(1.8,3.75);
    glVertex2f(2.0,3.75);
    glVertex2f(2.0,3.75);
    glVertex2f(2.0,3.5);
    glVertex2f(2.0,3.5);
    glVertex2f(1.8,3.5);
    glVertex2f(2.0,3.5);
    glVertex2f(2.0,3.25);
    glVertex2f(2.0,3.25);
    glVertex2f(1.8,3.25);
    glEnd();
    glFlush();   //elementos carregados no buffer


    glBegin(GL_LINE_LOOP);
    glVertex2f(x+2.0,y);
    glVertex2f(x2+2.0,y2);
    glVertex2f(x3+2.0,y3);
    glVertex2f(x4+2.0,y4);
    glEnd();
    glFlush();   //elementos carregados no buffer

    glBegin(GL_LINES);
    glVertex2f(x8+0.5,y8);
    glVertex2f(x9+0.5,y9);
    glVertex2f(x7+3.5,y7);
    glVertex2f(x6+3.5,y6);

    glBegin(GL_LINES);
    glVertex2f(x9+0.5,y9);
    glVertex2f(x7+3.5,y7);
    glVertex2f(x2+2.0,y2);
    glVertex2f(x8+0.5,y8);
    glVertex2f(x6+3.5,y6);
    glVertex2f(x3+2.0,y3);
    glEnd();
    glFlush();   //elementos carregados no buffer

    glBegin(GL_LINES);
    glVertex2f(x9+1.25,y9-4.5);
    glVertex2f(x4+2.0,y4);
    glVertex2f(x9+1.25,y9-4.5);
    glVertex2f(x+2.0,y);
    glEnd();
    glFlush();   //elementos carregados no buffer

    glBegin(GL_POLYGON);
    glColor3f(r+1.0,g,b);
    x = x+3.75;
    y = y + 1.5;
    x2 = x2 + 3.75;
    y2 = y2 + 1.5;
    x3 = x3 + 4.25;
    y3 = y3 + 1.5;
    x4 = x4 + 4.25;
    y4 = y4 + 1.5;
    x5 = x5 + 3.5;
    y5 = y5 + 3.0;
    x6 = x6 + 5.25;
    y6 = y6 - 0.5;
    glVertex2f(x,y);
    glVertex2f(x2,y2);
    glVertex2f(x3,y3);
    glVertex2f(x4,y4);
    glVertex2f(x6,y6);
    glVertex2f(x5,y5);
    glEnd();
    glFlush();   //elementos carregados no buffer

    glBegin(GL_POLYGON);
    glColor3f(r,g,b);
    glVertex2f(1.5,0.0);
    glVertex2f(2.0,-2.0);
    glVertex2f(2.5,0.0);
    glEnd();
    glFlush();   //elementos carregados no buffer

    //preenche o quadrado
    glBegin(GL_QUADS);
    glColor3f(r,g,b);
    glVertex2f(1.5,0.0);
    glVertex2f(1.5,1.0);
    glVertex2f(2.5,1.0);
    glVertex2f(2.5,0);
    glEnd();
    glFlush();   //elementos carregados no buffer

    fclose(fp);

}



void mouse(int button, int state, int x, int y)
{

if ((button == GLUT_LEFT_BUTTON ) && (state == GLUT_DOWN) && (x>500))
{
    printf("Mouse esquerdo clicado\n");
    printf("%d",x);
    r=(GLfloat)rand()/(RAND_MAX+1.0);
    g=(GLfloat)rand()/(RAND_MAX+1.0);
    b=(GLfloat)rand()/(RAND_MAX+1.0);
    desenha();
}
}


// Fun��o callback chamada quando o tamanho da janela � alterado
void AlteraTamanhoJanela(GLsizei w, GLsizei h)
{
    // Evita a divisao por zero
    if(h == 0) h = 1;

    // Especifica as dimens�es da Viewport
    glViewport(0, 0, w, h);

    // Inicializa o sistema de coordenadas
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // Estabelece a janela de sele��o (left, right, bottom, top)
    if (w <= h)
        gluOrtho2D (0.0f, 250.0f, 0.0f, 250.0f*h/w);
    else
        gluOrtho2D (0.0f, 250.0f*w/h, 0.0f, 250.0f);
}


void teclas(unsigned char tecla, GLint x, GLint y)
{
    switch(tecla)
    {
    case '+':  //se apertar a tecla +, a figura aumenta
        escala++;
        break;
    case '-':  //se apertar a tecla -, a figura diminui
        escala--;
        break;
    case '1':  //se apertar a tecla 1, a rotacao � aumentada
        rotacao+=3;
        break;
    case '2':  //se apertar a tecla 2, a rotacao � decrementada
        rotacao-=3;
        break;
    }
    desenha();
}

void teclasEspeciais(GLint tecla, GLint x, GLint y)
{
    switch(tecla)
    {
    case GLUT_KEY_UP:  //se apertar a tecla seta pra frente, a figura vai para frente
        movy++;
        break;
    case GLUT_KEY_DOWN: //se apertar a tecla seta pra atr�s, a figura vai para atr�s
        movy--;
        break;
    case GLUT_KEY_LEFT:  //se apertar a tecla seta pra esquerda, a figura vai para esquerda
        movx--;
        break;
    case GLUT_KEY_RIGHT:  //se apertar a tecla seta pra direita, a figura vai para direita
        movx++;
        break;
    }
    desenha();
}



int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);   //inicia 1 buffer e o aspecto de cores RGB
    glutInitWindowSize(700,400);
    glutInitWindowPosition(320,150);
    glutCreateWindow("Trabalho OpenGl");
    glutSpecialFunc(teclasEspeciais);
    glutKeyboardFunc(teclas);
    glutDisplayFunc(desenha);   //chama a funcao desenha toda vez que a janela for alterada (diminuida por exemplo)
    glutMouseFunc(mouse);
    glutReshapeFunc(AlteraTamanhoJanela);
    glClearColor(0,0,1,0);  //cor da janela (padrao RGB alpha)
    glutMainLoop();    //loop que aguarda o encerramento da aplica��o
    return 0;
}
